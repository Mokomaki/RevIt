//Application controls
document.getElementById("win_close").addEventListener('click', function() 
{
  window.CloseWindow();
});
document.getElementById("win_min").addEventListener('click', function() 
{
  window.MinimizeWindow();
});
document.getElementById("win_max").addEventListener('click', function() 
{
  window.MaximizeWindow();
});