window.addEventListener('load', function () 
{
    window.GetTitleById();
    window.GetPostContentsById();
});